PNG and pixel-identical lossless WebP assets are in game-ready/. See manifest.json. These files are review candidates; runtime installation has not been performed.
Source, previews and Japanese documentation:
https://github.com/haseatsu114514-dot/shisha-game/tree/codex/kafuka-parts-and-nagoya-map-20261007/asset_sources/portraits/kafuka-approved-blue-inner-v1
