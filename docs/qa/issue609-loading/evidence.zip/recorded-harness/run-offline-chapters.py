from pathlib import Path
import os,subprocess,json
root=Path(__file__).resolve().parent
out=root/'evidence/offline'
common={**os.environ,'NODE_PATH':'/tmp/shisha-load609-runtime/node_modules','CHROME_EXECUTABLE_PATH':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','OFFLINE_FIXED_RANDOM':'1'}
status_path=out/'run-status.json'
rows=json.loads(status_path.read_text()) if status_path.exists() else []
def run(name,target,port,mobile='0',expected=0):
 folder=out/name
 prior=next((r for r in rows if r['name']==name),None)
 if prior:
  if prior['exit']==expected and prior['unexpected']==[] and (folder/'measurement.json').exists() and (folder/'offline-network.json').exists():
   print('SKIP completed',name,flush=True);return
  raise SystemExit('Inspect previous result '+name+' before retrying')
 env={**common,'BASE_URL':f'http://127.0.0.1:{port}/remake/','AUDIT_DIR':str(folder),'ARTIFACT_DIR':str(folder),'MOBILE':mobile}
 print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['node','offline-run.mjs',target],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 netpath=folder/'offline-network.json';net=json.loads(netpath.read_text()) if netpath.exists() else None
 row={'name':name,'exit':r.returncode,'expectedExit':expected,'guardedPages':net and net['pages'],'externalAttempts':net and len(net['records']),'externalBytes':net and sum(x['bytes'] for x in net['records']),'unexpected':net and net['unexpected']}
 rows.append(row);(out/'run-status.json').write_text(json.dumps(rows,indent=2)+'\n');print('DONE',json.dumps(row),flush=True)
 if not net or net['unexpected'] or r.returncode!=expected:raise SystemExit('Inspect '+name+' before continuing')
for device,mobile in [('pc','0'),('touch','1')]:
 for change,port in [('before',8610),('after',8609)]:run(change+'-'+device,'offline-chapter.mjs',port,mobile)
print('COMPLETE',flush=True)
