from pathlib import Path
import os,subprocess,json
root=Path(__file__).resolve().parent
out=root/'evidence/resume609-20261018'
common={**os.environ,'NODE_PATH':'/Applications/ChatGPT.app/Contents/Resources/cua_node/lib/node_modules','CHROME_EXECUTABLE_PATH':'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','BASE_URL':'http://127.0.0.1:8609/remake/','TEST_REF':'913520169855dbe90208fdfd8d7186bb88abf4e1 + #609 integrated'}
rows=[]
for label,target in [('title','evidence/resume609-20261018/main-files/remake/test/browser/ch1_title_motion.mjs'),('save','work/shisha-game/remake/test/browser/save_load.mjs'),('craft','work/shisha-game/remake/test/browser/craft_readiness.mjs'),('navigation','work/shisha-game/remake/test/navigation_transitions.mjs')]:
 folder=out/label;env={**common,'ARTIFACT_DIR':str(folder),'AUDIT_DIR':str(folder)}
 print('START',label,flush=True)
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(['node','integration-offline-run.mjs',target],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 net=json.loads((folder/'offline-network.json').read_text())
 rows.append({'label':label,'exit':r.returncode,'externalBytes':sum(x['bytes'] for x in net['records']),'unexpected':net['unexpected']});(out/'integration-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('DONE',json.dumps(rows[-1]),flush=True)
 if r.returncode or net['unexpected']:raise SystemExit('Inspect '+label+' before continuing')
print('COMPLETE',flush=True)
