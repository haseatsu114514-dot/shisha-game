// Disposable test-only network guard. No OS, repository, or user profile settings change.
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';
const {chromium}=createRequire('/Applications/ChatGPT.app/Contents/Resources/cua_node/lib/node_modules/playwright/package.json')('playwright');
const out=path.resolve(process.env.AUDIT_DIR||process.env.ARTIFACT_DIR||'evidence/offline');
await fs.mkdir(out,{recursive:true});
const originalLaunch=chromium.launch;
const guarded=new WeakSet(),records=[],browsers=[];
const local=url=>{try{return ['127.0.0.1','localhost','[::1]'].includes(new URL(url).hostname);}catch{return false;}};
let pages=0;
async function guard(page){
 if(guarded.has(page))return;guarded.add(page);pages++;
 const cdp=await page.context().newCDPSession(page);
 await cdp.send('Network.enable');
 // Unlike Playwright routing, CDP blocking preserves the real browser HTTP cache.
 await cdp.send('Network.setBlockedURLs',{urlPatterns:[
  {urlPattern:'blob:*',block:false},
  {urlPattern:'data:*',block:false},
  {urlPattern:'http://127.0.0.1:*/*',block:false},
  {urlPattern:'http://localhost:*/*',block:false}
 ],urls:['http://*','https://*','ws://*','wss://*']});
 const pending=new Map();
 cdp.on('Network.requestWillBeSent',e=>{
  if(!/^https?:/.test(e.request.url)||local(e.request.url))return;
  const row={url:e.request.url,at:e.wallTime,bytes:0};records.push(row);pending.set(e.requestId,row);
 });
 cdp.on('Network.dataReceived',e=>{const r=pending.get(e.requestId);if(r)r.bytes+=e.encodedDataLength;});
 cdp.on('Network.responseReceived',e=>{const r=pending.get(e.requestId);if(r)r.responseStatus=e.response.status;});
 cdp.on('Network.loadingFailed',e=>{const r=pending.get(e.requestId);if(r)Object.assign(r,{error:e.errorText,blockedReason:e.blockedReason});});
 cdp.on('Network.loadingFinished',e=>{const r=pending.get(e.requestId);if(r)r.completedBytes=e.encodedDataLength;});
 await page.addInitScript(()=>{performance.setResourceTimingBufferSize(10000);});
 if(process.env.OFFLINE_FIXED_RANDOM==='1')await page.addInitScript(()=>{Math.random=()=>0.5;});
}
chromium.launch=async options=>{
 const browser=await originalLaunch.call(chromium,{...options,args:[...(options?.args||[]),
  '--proxy-server=http://127.0.0.1:9','--proxy-bypass-list=127.0.0.1;localhost;[::1]']});
 browsers.push(browser);
 const newContext=browser.newContext.bind(browser),newPage=browser.newPage.bind(browser);
 browser.newContext=async options=>{
  const context=await newContext({...options,serviceWorkers:'block'});
  const create=context.newPage.bind(context);
  context.newPage=async()=>{const page=await create();await guard(page);return page;};
  return context;
 };
 browser.newPage=async options=>{const page=await newPage({...options,serviceWorkers:'block'});await guard(page);return page;};
 return browser;
};
let failure=null;
try {await import(pathToFileURL(path.resolve(process.argv[2])).href);}
catch(e){failure=e.stack;console.error(e);}
finally{
 const unexpected=records.filter(r=>r.responseStatus||r.bytes||r.completedBytes||r.blockedReason!=='inspector');
 const report={condition:'localhost only; CDP external URL blocking plus loopback-only proxy for browser egress; production audio fallback',fixedRandom:process.env.OFFLINE_FIXED_RANDOM==='1'?0.5:null,pages,records,unexpected,failure};
 await fs.writeFile(path.join(out,'offline-network.json'),JSON.stringify(report,null,2)+'\n');
 console.log('OFFLINE_NETWORK',JSON.stringify({pages,attempts:records.length,externalBytes:records.reduce((a,r)=>a+r.bytes,0),unexpected:unexpected.length}));
 for(const b of browsers)await b.close().catch(()=>{});
 chromium.launch=originalLaunch;
 if(failure||unexpected.length)process.exitCode=1;
}
