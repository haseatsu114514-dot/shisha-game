from pathlib import Path
import sys,json,hashlib
from urllib.parse import urlsplit,unquote
from functools import partial
TASK=Path(__file__).resolve().parent
REPO=TASK/'work/shisha-game'
CACHE=TASK/'evidence/resume609-20261018/main-files'
sys.path.insert(0,str(REPO/'remake/tools'))
from serve_load_audit import AuditHandler,AuditServer
metadata=TASK/'evidence/resume609-20261018/tree-metadata'
expected={}
for prefix,name in [('remake/js','remake-js'),('remake/css','remake-css'),('data','data'),('remake/data','remake-data')]:
 for item in json.loads((metadata/(name+'.json')).read_text())['tree']:
  if item['type']=='blob':expected[prefix+'/'+item['path']]=item['sha']
expected['remake/index.html']=next(x['sha'] for x in json.loads((metadata/'remake.json').read_text())['tree'] if x['path']=='index.html')
for item in json.loads((TASK/'evidence/resume609-20261018/remaining8-assets.json').read_text()):
 expected[item['path']]=item['sha']
ours={'remake/js/core/ui.js','remake/js/vn/engine.js','remake/js/craft/session.js'}
served={};log=TASK/'evidence/resume609-20261018/served-files.json'
class Handler(AuditHandler):
 def translate_path(self,path):
  name=unquote(urlsplit(path).path).lstrip('/')
  if name in ['remake','remake/']:name='remake/index.html'
  if name in expected:
   target=REPO/name if name in ours else CACHE/name if (CACHE/name).is_file() else REPO/name
   if not target.is_file():print('MISSING_MAIN_TEXT',name,flush=True);return str(CACHE/'__missing__'/name)
   data=target.read_bytes();sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if name not in ours and sha!=expected[name]:print('STALE_MAIN_TEXT',name,sha,expected[name],flush=True);return str(CACHE/'__missing__'/name)
   served[name]={'blob':sha,'source':'candidate' if name in ours else 'main','bytes':len(data)}
   log.write_text(json.dumps(served,indent=2)+'\n')
   return str(target)
  return super().translate_path(path)
with AuditServer(('127.0.0.1',8609),partial(Handler,directory=str(REPO))) as server:
 print('Verified API main9135201 + #609 candidate at http://127.0.0.1:8609/remake/',flush=True)
 server.serve_forever()
